//var form = document.querySelector('form');
var obj= document.forms[0];
// var form = document.querySelector('form');
obj.addEventListener("submit", function(e)
{




var len = obj.elements.length;
var text = "";
for (var i=0; i < len -2; i++)
{

if ((obj.elements[i].value == "") || (obj.elements[i].value == null))
{

	alert("Make sure to input " + obj.elements[i].name);
	obj.elements[i].focus();
	obj.elements[i].select();
	obj.elements[i].style.backgroundColor="red";
	// to stop form from submitting to new page
	 e.preventDefault();
	return;
}
else if ((i == 2 ) && (obj.elements[i].value.length != 5)  )
{

	alert("Make sure to input 5 digits for " + obj.elements[i].name);
	obj.elements[i].focus();
	obj.elements[i].select();
	obj.elements[i].style.backgroundColor="red";
	// to stop form from submitting to new page
	 e.preventDefault();
	return;
}

else if ((i == 3 ) && (obj.elements[i].value.indexOf("@") == -1)  )
{

	alert("Your email should inlcude an @ " + obj.elements[i].name);
	obj.elements[i].focus();
	obj.elements[i].select();
	obj.elements[i].style.backgroundColor="red";
	// to stop form from submitting to new page
	 e.preventDefault();
	return;
}

else if ((i == 3 ) && (obj.elements[i].value.indexOf(".") == -1)  )
{

	alert("Your email should inlcude an . " + obj.elements[i].name);
	obj.elements[i].focus();
	obj.elements[i].select();
	obj.elements[i].style.backgroundColor="red";
	// to stop form from submitting to new page
	 e.preventDefault();
	return;
}

else 
{

text += obj.elements[i].name;
text += ":";
text += obj.elements[i].value;

text += "<p>";
}

}

document.getElementById("demo").innerHTML= text;
console.log(text);

});