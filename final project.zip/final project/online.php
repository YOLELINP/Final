<!DOCTYPE HTML>

<html>
<head>
<title>PHP: online store</title>
<link rel="stylesheet" type="text/css" href="custom.css">
</head>
<body>

<?php
$x=floatval($_POST['amount']);
$line = "";

print("<h2> Thank you for helping the Children!");

foreach ($_POST as $key => $value)
{

$line .= $value . ":";


print("<li> $key: $value ");
}
print("<li> Your donation amount: "); echo $x;

fwrite($filea, $line);

fclose($filea);

?>
</body>
</html>